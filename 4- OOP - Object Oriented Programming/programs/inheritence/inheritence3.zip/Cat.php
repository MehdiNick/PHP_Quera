<?php


class Cat extends Carnivore{

	public function Meow(){
		return "Meow, meow!";
	}

public function Run(){
	return "Run!";
}


}


?>