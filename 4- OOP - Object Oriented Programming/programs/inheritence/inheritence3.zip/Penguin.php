<?php


class Penguin extends Carnivore{

	public function grabFish(){
		return "Fish grabbed successfully!";
	}

}


?>