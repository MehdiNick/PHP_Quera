<?php


class Giraffe extends Vegetarian{

	public function Walk(){
		return "Walking...";
	}

}


?>